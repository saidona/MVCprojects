import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import Home from './home';
describe('Home component',()=>{
    test('renders learn react link', () => {
        //Arrange
        render(<Home />);
        const linkElement = screen.getByText(/Hello/i);
        //Assert
        
      });
      test('renders Modified on button clicked', () => {
        //Arrange
      render(<Home />);
      //Act
      const button1 = screen.getByRole('button');
      userEvent.click(button1);
      const modifiedtxt = screen.getByText(/Modified/i);
      //Assert
      expect(modifiedtxt).toBeInTheDocument();
    });

    test('renders text that is not supposed to be visible', () => {
        //Arrange
      render(<Home />);
      //Act
      const button1 = screen.getByRole('button');
      userEvent.click(button1);
      const modifiedtxt = screen.queryByText(/Text supposed to be displayed after/i,{exact:false});
      //Assert
      expect(modifiedtxt).toBeNull();
    });
   
     
      
})
