import {useState} from 'react';
const Home=()=>{
const [changedMsg,setChangedMsg]=useState(false);
const ChangedMsgHandler = ()=>{
setChangedMsg(true);
};
return(
<div><h1>Hello world!</h1>

{!changedMsg && <p>Hi, glad to meet!</p>}
{changedMsg && <p>Modified!</p>}
<button onClick={ChangedMsgHandler}>Modify msg</button>
</div>
);
};
export default Home;