import logo from './logo.svg';
import Async from './components/Async';
import './App.css';

function App() {
  return (
    <Async/>
  );
}

export default App;
